#include <ics46/factory/DynamicFactory.hpp>
#include "JustAI.hpp"
#include <iostream>
#include "OthelloGameState.hpp"
	
ICS46_DYNAMIC_FACTORY_REGISTER(OthelloAI, shiqih1::JustAI, "**|EUREKA|**(Required)");

std::pair<int, int> shiqih1::JustAI::chooseMove(const OthelloGameState& state)
{
   
	int winner = -10000000;
	std::pair<int, int> result;
	bool is_white_turn = state.isWhiteTurn();
	int width = state.board().width();
	int height = state.board().height();
	for (int h = 0; h < height; h++) {
		for (int w = 0; w < width; w++) {
			if (state.isValidMove(w, h)) {
				std::unique_ptr<OthelloGameState> new_state = state.clone();
				new_state->makeMove(w, h);
			//	std::cout << "move " << w << h << std::endl;
				int temp = path_searching(*new_state, is_white_turn, 2);
			//	std::cout <<" scored: "<<temp << std::endl;
				if (temp > winner) {
					result = std::make_pair(w, h);
					winner = temp;
					}
				}
			}
		}
	
	//std::cout << "chose  " << winner << std::endl;
	return result;

}	

int shiqih1::JustAI::path_searching(const OthelloGameState &state, bool is_white_turn, int depth)
{
	int result;
	if (state.isWhiteTurn() == is_white_turn) result = -10000;
	else result = 10000;
	if ( state.isGameOver()||depth==0) return eval_state(state,is_white_turn);
	else {
		int width = state.board().width();
		int height = state.board().height();
		for (int h = 0; h < height; h++) {
			for (int w = 0; w < width; w++) {
				if (state.isValidMove(w, h)) {
					std::unique_ptr<OthelloGameState> new_state = state.clone();
					new_state->makeMove(w, h);
					int temp = path_searching(*new_state, is_white_turn, depth-1);
					if (state.isWhiteTurn() == is_white_turn) {
						if (temp > result) result = temp;
					}
					else {
						if (temp < result) result = temp;
					}
				}
			}
		}
	}
    /*
	std::cout << "turn: " << state.isWhiteTurn() << " chose: " << result << std::endl;*/
	return result;
}

int shiqih1::JustAI::eval_state(const OthelloGameState& state,bool is_white_turn)
{
	int score = 0;;
	int width = state.board().width();
	int height = state.board().height();
	int white_corners = 0;
	int white_edges = 0;
	int black_corners = 0;
	int black_edges = 0;
	for (int h = 0; h < height; h++) {
		for (int w = 0; w < width; w++) {
			if (state.board().cellAt(w, h) == OthelloCell::black)
			{
				if ((h==0||h==(height-1)) && (w==0||w==(width-1))){
					black_corners += 1;
				}
                if (!(is_white_turn))
                      { if ((w==1&&h== 0) || (w==0&&h== 1) || (w==1&&h== 1)|| (w==(width-2)&&h== 1) ||(w==width-2&&h== 0) || 
                      (w==(width-1)&&h==1) ||(w==0&&h== height-2) ||(w==1&&h== height-2) ||
                         (w==1&&h==height-1) ||(w==width-2&&h== height-2) ||(w==width-1&&h== height-2)
                         ||(w==width-2&&h== height-1))   {score -=height*height/2;}}

				else if (h == 0 || w == 0) {
					black_edges += 1;
				}
				
			}
			else if (state.board().cellAt(w, h) == OthelloCell::white)
			{
				if ((h == 0 || h == (height - 1)) && (w == 0 || w == (width - 1))) {
					white_corners += 1;
				}
                if (is_white_turn)
               { if ((w==1&&h== 0) || (w==0&&h== 1) || (w==1&&h== 1)||
                         (w==(width-2)&&h== 1) ||(w==width-2&&h== 0) || (w==(width-1)&&h==1) ||(w==0&&h== height-2) ||(w==1&&h== height-2) ||
                         (w==1&&h==height-1) ||(w==width-2&&h== height-2) ||(w==width-1&&h== height-2) ||(w==width-2&&h== height-1) ) 
                         {score -=height*height/2;}}
				else if (h == 0 || w == 0) {
					
                    
                    white_edges += 1;
				}
			}
			else 
			{
				if (state.isValidMove(w, h)) {
					if (state.isWhiteTurn() == is_white_turn)  score += height/2;
					else score -= height/2;
				} 
				
			}

		}
	}
	if (is_white_turn) {
		if (state.isGameOver() && state.isWhiteTurn()) {
			if ((state.whiteScore() - state.blackScore()) > 0) return 10000;
			else return -100000;
		}
	
			score += (state.whiteScore() - state.blackScore());
		
			score += ((white_corners - black_corners) * height *height);
			score += ((white_edges - black_edges) * height);
		
	}
	else {
		if (state.isGameOver() && state.isBlackTurn()) {
			if ((state.blackScore() - state.whiteScore()) > 0) return 100000;
			else return -100000;
		}
		score += (state.blackScore() - state.whiteScore());

		score += ((black_corners - white_corners) * height * height);
		score += ((black_edges - white_edges) * height);
		}
        /*
	std::cout<<"white scores "<<state.whiteScore()<<" black scores "<<state.blackScore()<<
		"white edges " << white_edges << " black edges " << black_edges<<
		"white corners " << white_corners <<  " black corners  " << black_corners
		<<std::endl<< "total score" << score<<std::endl;*/
	return score;
	
}
